package com.example.demo;

import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestNGTestScenarios {
	private final String userName = "abhilash14rajat";
	private final String accessKey = "PCBPreKEqdGkZWzPnTuAdJBzHMKKVhVuoN72rzhR134XbmbDf7";
	private final String gridUrl = "https://hub.lambdatest.com/wd/hub";

	RemoteWebDriver driver;
	SoftAssert softAssert;
	HashMap<String, Object> ltOptions = new HashMap<>();

	// Initializing WebDriver and URL from XML
	@BeforeMethod
	@Parameters({ "browser", "version", "platform", "url" })
	public void setup(String browser, String version, String platform, String url) throws Exception {

		ltOptions = new HashMap<>();
		ltOptions.put("username", userName);
		ltOptions.put("accessKey", accessKey);
		ltOptions.put("visual", true);
		ltOptions.put("video", true);
		ltOptions.put("network", true);
		ltOptions.put("build", "TestNG_101");
		ltOptions.put("project", "TestNGProject");
		ltOptions.put("console", "info");
		ltOptions.put("selenium_version", "4.0.0");
		ltOptions.put("w3c", true);

		// Browser setup based on parameters
		if (browser.equalsIgnoreCase("chrome")) {
			ChromeOptions chrome = new ChromeOptions();
			chrome.setCapability("browserName", "chrome");
			chrome.setCapability("browserVersion", version);
			chrome.setCapability("platformName", platform);
			chrome.setCapability("LT:Options", ltOptions);
			driver = new RemoteWebDriver(new URL(gridUrl), chrome);
		}
		else if (browser.equalsIgnoreCase("firefox")) {
			FirefoxOptions firefox = new FirefoxOptions();
			firefox.setCapability("browserName", "firefox");
			firefox.setCapability("browserVersion", version);
			firefox.setCapability("platformName", platform);
			firefox.setCapability("LT:Options", ltOptions);
			driver = new RemoteWebDriver(new URL(gridUrl), firefox);
		} 
		else if (browser.equalsIgnoreCase("MicrosoftEdge")) {
			EdgeOptions edge = new EdgeOptions();
			edge.setCapability("browserName", "MicrosoftEdge");
			edge.setCapability("browserVersion", version);
			edge.setCapability("platformName", platform);
			edge.setCapability("LT:Options", ltOptions);
			driver = new RemoteWebDriver(new URL(gridUrl), edge);
		} 

		driver.get(url);
		softAssert = new SoftAssert();
	}


	// Test Scenario 1 - Validate the page title
	@Test(priority = 1)
	public void testScenario1()
     {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body"))); // Wait added for body tag to be present

		String pageTitle = driver.getTitle();
		System.out.println("Page Title: " + pageTitle);

		softAssert.assertEquals(pageTitle, "LambdaTest"); // Expected failure here as actual page title is different
	}

	// Test Scenario 2 - Checkbox Selection and Unselection
	@Test(priority = 2)
	public void testScenario2() 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		// Click "Checkbox Demo" link
		driver.findElement(By.linkText("Checkbox Demo")).click();

		// Wait for the "Single Checkbox Demo" section to be visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Single Checkbox Demo']")));

		// Click the checkbox under "Single Checkbox Demo"
		WebElement checkbox = driver.findElement(By.id("isAgeSelected"));
		checkbox.click();

		// Validate if the checkbox is "selected"
		softAssert.assertTrue(checkbox.isSelected(), "Checkbox should be selected");

		// Unselect the checkbox
		checkbox.click();

		// Validate if the checkbox is "unselected"
		softAssert.assertFalse(checkbox.isSelected(), "Checkbox should be unselected");
	}

	// Test Scenario 3 - JavaScript Alert Handling
	@Test(priority = 3)
	public void testScenario3()
	{
		// Step 1: Click "Javascript Alerts" link
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		driver.findElement(By.linkText("Javascript Alerts")).click();

		// Wait for the "Click Me" button to be visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Click Me')]")));

		// Step 2: Click the "Click Me" button to trigger the alert
		driver.findElement(By.xpath("//button[contains(text(),'Click Me')]")).click();

		// Step 3: Handle the alert and validate the message
		Alert alert = driver.switchTo().alert();
		String alertMessage = alert.getText();
		System.out.println("Alert Message: " + alertMessage);

		// Validate the alert message
		softAssert.assertEquals(alertMessage, "I am an alert box!", "Alert message doesn't match.");

		// Step 4: Click OK to dismiss the alert
		alert.accept();
	}

	@AfterMethod
	public void closebrowser() {
		if (driver != null) {
			driver.quit(); // Close the browser
		}
	}


}
